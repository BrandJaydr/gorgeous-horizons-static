# Gorgeous Horizons – Static Calendar

A beautifully styled static HTML calendar designed for singles, event-goers, and community curators.

## Features
- Monthly layout
- Hover effects
- Color-branded design

## Usage
Open `index.html` in a browser or host it as a static webpage.

## License
GPL v3 – Use freely, but keep it open source.
